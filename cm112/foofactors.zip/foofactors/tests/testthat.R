library(testthat)
library(foofactors)

test_check("foofactors")
